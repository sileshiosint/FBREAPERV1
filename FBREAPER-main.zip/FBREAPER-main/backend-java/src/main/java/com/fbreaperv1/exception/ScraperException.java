package com.fbreaperv1.exception;

public class ScraperException extends RuntimeException {
    public ScraperException(String message) {
        super(message);
    }
}
