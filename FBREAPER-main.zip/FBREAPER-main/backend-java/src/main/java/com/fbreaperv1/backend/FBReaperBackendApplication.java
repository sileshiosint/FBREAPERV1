package com.fbreaperv1.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FBReaperBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(FBReaperBackendApplication.class, args);
    }
}
