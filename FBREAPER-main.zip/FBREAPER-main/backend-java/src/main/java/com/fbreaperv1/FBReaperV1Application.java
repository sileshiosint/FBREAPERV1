package com.fbreaperv1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FBReaperV1Application {

    public static void main(String[] args) {
        SpringApplication.run(FBReaperV1Application.class, args);
    }
}
